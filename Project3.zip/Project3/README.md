Compile:
c++ -o bankers bankers.cpp

Run:
./bankers
