Compile:
gcc -o philosopher philosopher.c -pthread 

Run:
./philosopher
