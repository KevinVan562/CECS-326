How to compile:
gcc filecopy.c -o filecopy

How to run:
Must have a source file created first, destination file can be created when running the program as long as you write destination.txt (can be any name .txt)

./filecopy input.txt output.txt
